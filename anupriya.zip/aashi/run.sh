#!/bin/bash

python3 -m geektrust sample_input/input1.txt
python3 -m geektrust sample_input/input2.txt
python3 -m geektrust sample_input/input3.txt
python3 -m geektrust sample_input/input4.txt
